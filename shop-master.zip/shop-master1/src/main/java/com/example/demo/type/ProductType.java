package com.example.demo.type;

public enum ProductType {
    CHAIR,
    ARMCHAIR,
    SOFA
}
