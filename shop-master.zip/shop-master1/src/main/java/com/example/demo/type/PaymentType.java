package com.example.demo.type;

public enum PaymentType {
    CASH,
    EMONEY
}
