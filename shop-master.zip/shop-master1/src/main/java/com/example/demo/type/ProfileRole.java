package com.example.demo.type;

public enum ProfileRole {
    ADMIN,
    USER,
    MODERATOR
}
