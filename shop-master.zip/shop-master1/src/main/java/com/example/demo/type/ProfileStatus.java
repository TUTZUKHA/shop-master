package com.example.demo.type;

public enum ProfileStatus {
    ACTIVE,
    INACTIVE,
    BLOCKED
}
