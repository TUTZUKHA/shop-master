package com.example.demo.type;

public enum OrderStatus {
    CREATED,
    PAID,
    DELIVERED,
    ON_THE_WAY
}
