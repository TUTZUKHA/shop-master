package com.example.demo.type;

public enum ProductStatus {
    PUBLISHED,
    CREATED,
    BLOCKED
}
